# CodeValidationRequestDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** | Email de l\&#39;utilisateur | [default to undefined]

## Example

```typescript
import { CodeValidationRequestDTO } from './api';

const instance: CodeValidationRequestDTO = {
    email,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
